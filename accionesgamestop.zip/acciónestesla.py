import yfinance as yf
import pandas as pd

tesla = yf.Ticker( "TSLA")
tesla_data = tesla.history(period = "max")
print (tesla_data.head())

import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.plot(tesla_data.index, tesla_data['Close'])
ax.set(xlabel='Fecha', ylabel= 'Precio de cierre', title= 'Grafico del precio de cierre acciones de Tesla')
ax.grid()

plt.show()