import yfinance as yf
import pandas as pd

gamestop = yf.Ticker( "GME")
gamestop_data = gamestop.history(period = "max")
print (gamestop_data.head())

import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.plot(gamestop_data.index, gamestop_data['Close'])
ax.set(xlabel='Fecha', ylabel= 'Precio de cierre', title= 'Grafico del precio de cierre acciones de GameStop')
ax.grid()

plt.show() 