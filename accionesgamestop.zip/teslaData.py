import yfinance as yf
import pandas as pd

tesla = yf.Ticker ("TSLA")
tesla_data = tesla.history (period = "max")
tesla_data.reset_index (inplace = True)
print (tesla_data.head()) 

import requests
from bs4 import BeautifulSoup
# URL de la página con los datos de ingresos de Tesla
url = 'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-PY0220EN-SkillsNetwork/labs/project/revenue.htm'

# Realizamos una solicitud HTTP para obtener el contenido de la página
response = requests.get(url)

# Creamos un objeto BeautifulSoup para analizar el contenido HTML
soup = BeautifulSoup(response.content, 'html.parser')

# Buscamos la tabla que contiene los datos de ingresos
table = soup.find('table')

# Imprimimos los datos de ingresos
for row in table.find_all('tr')[1:]:
    columns = row.find_all('td')
    year = columns[0].text
    revenue = columns[1].text
    print(f"Año {year}: Ingresos = {revenue}")

    # Obtenemos los ultimos 5 registros útilizando funcción tail
    ultimos_registros = tesla_data
    tesla_data = tesla.tail (5)
    print (ultimos_registros)
import yfinance as yf
import pandas as  pd
import plotly.express as px
    # Descarga datos 
    #Descarga y crear  grafico de dátos f"Año {year}: Ingresos = {revenue}"
df = px.data.iris()
    # Crear un gráfico de disperción
fig = px.scater (df, x = 'sepal_width', y = 'sepal_legth', color = 'species', title = 'iris Spal Width vs Length')
    # Monstrar el grafico
fig.show()
    
